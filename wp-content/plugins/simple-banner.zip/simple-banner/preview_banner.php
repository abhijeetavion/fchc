<div id="preview_banner_outer_container<?php echo $banner_id ?>" class="simple-banner-settings-section" style="<?php echo $banner_id === '' ? '' : 'display:none;' ?>min-height: 40px;">
	<div id="preview_banner_inner_container<?php echo $banner_id ?>">
		<div id="preview_banner<?php echo $banner_id ?>" class="simple-banner<?php echo $banner_id ?>" style="width: 100%;text-align: center;">
			<div id="preview_banner_text<?php echo $banner_id ?>" class="simple-banner-text<?php echo $banner_id ?>" style="font-weight: 700;padding: 10px;">
				<span>This is what your banner will look like with a <a href="/">link</a>.</span>
			</div>
		</div>
	</div>
</div>