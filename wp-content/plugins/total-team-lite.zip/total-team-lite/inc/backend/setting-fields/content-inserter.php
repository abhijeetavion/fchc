<div class="ttp-input-field-wrap" id="totalteam-inner-custom-shortcode-popup" style="display:none">
    <label>
        <?php echo __('Select Content Type', TOTAL_TEAM_LITE_TEXT_DOMAIN); ?>
    </label>
    <div class="ttp-input-field">
        <select name="team_layout_type" id="ttp-team-member-content-insertion-type" class="ttp-dropdown">
            <option value=""><?php _e('Choose Content', TOTAL_TEAM_LITE_TEXT_DOMAIN); ?></option>
            <option value="title"><?php _e('Title', TOTAL_TEAM_LITE_TEXT_DOMAIN); ?></option>
            <option value="subtitle"><?php _e('Subtitle', TOTAL_TEAM_LITE_TEXT_DOMAIN); ?></option>
            <option value="skill"><?php _e('Skills', TOTAL_TEAM_LITE_TEXT_DOMAIN); ?></option>
        </select>
    </div>
</div>