<?php defined('ABSPATH') or die('No script kiddies please!'); ?>

<div class="ttp-head">     
    <h3 style="font-size: 24px; color: #fff; text-transform: uppercase; font-family: serif;">Total Team Lite</h3>
<!--<img src="<?php //echo TOTAL_TEAM_LITE_IMAGE_DIR.'/total-team-lite-logo.png';  ?>" alt="<?php //_e('Total Team Lite', TOTAL_TEAM_LITE_TEXT_DOMAIN); ?>" style="
    color: #fff;
"/>-->
</div> 
